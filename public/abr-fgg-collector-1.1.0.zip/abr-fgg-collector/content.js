(() => {
  console.log('[ABR-FGG] content.js carregado em:', window.location.href);

  // ---------- Utilitários ----------

  function normalizeText(text) {
    return (text || '')
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/\s+/g, ' ')
      .trim()
      .toLowerCase();
  }

  function textToInt(el) {
    if (!el) return null;

    const txt = (el.textContent || '').replace(/[^\d-]/g, '');
    const n = parseInt(txt, 10);

    return Number.isNaN(n) ? null : n;
  }

  // Converte "2:16.355s" ou "1.389s" para segundos
  function parseLapTimeToSeconds(text) {
    if (!text) return 0;

    const clean = String(text).replace(/[^\d:.]/g, '').trim();

    if (!clean) return 0;

    if (clean.includes(':')) {
      const parts = clean.split(':');

      const minutes = parseFloat(parts[0]);
      const seconds = parseFloat(parts[1]);

      if (Number.isNaN(minutes) || Number.isNaN(seconds)) return 0;

      return Number((minutes * 60 + seconds).toFixed(3));
    }

    const value = parseFloat(clean);

    return Number.isNaN(value) ? 0 : Number(value.toFixed(3));
  }

  // Converte texto do pneu para código numérico
  function tyreTextToCode(text) {
    const t = normalizeText(text || '')
      .replace(/[^a-z0-9]+/g, ' ')
      .trim();

    if (t.includes('super macio')) return 1;
    if (t.includes('macio')) return 2;
    if (t.includes('medio')) return 3;
    if (t.includes('duro')) return 4;
    if (t.includes('chuva')) return 6;

    return 0;
  }

  // Mantém o nome do pneu como texto
  function tyreTextToLabel(text) {
    return (text || '').replace(/\s+/g, ' ').trim();
  }

  // Valor pelo texto do <th> vizinho (Reputação, Peso, Idade, Total)
  function findValueByLabel(labelContains) {
    const ths = document.querySelectorAll('th');

    for (const th of ths) {
      const txt = (th.textContent || '').trim();

      if (txt.includes(labelContains)) {
        const tr = th.closest('tr');

        if (tr) {
          const tds = tr.querySelectorAll('td');

          for (let i = tds.length - 1; i >= 0; i--) {
            const v = textToInt(tds[i]);
            if (v !== null) return v;
          }
        }
      }
    }

    return null;
  }

  function parseWearText(text) {
  const clean = String(text || '').replace(/[^0-9]/g, '');
  const n = parseInt(clean, 10);

  return Number.isNaN(n) ? null : n;
}

  // Procura uma linha pelo título do <th> e retorna os valores dos <td>
  function findRowTdValuesByHeader(headerText) {
    const target = normalizeText(headerText);
    const rows = document.querySelectorAll('tr');

    for (const tr of rows) {
      const ths = tr.querySelectorAll('th');

      const found = Array.from(ths).some((th) =>
        normalizeText(th.textContent).includes(target)
      );

      if (!found) continue;

      const tds = tr.querySelectorAll('td');
      const values = Array.from(tds).map((td) => textToInt(td));

      if (values.length > 0) return values;
    }

    return [];
  }

  // ---------- Detectores de página ----------

  const isDriverPage = () =>
    window.location.href.toLowerCase().includes('driverprofile');

  const isCarPage = () =>
    window.location.href.toLowerCase().includes('updatecar');

  const isRacePage = () => {
    const u = window.location.href.toLowerCase();
    return u.includes('qualify') || u.includes('racesetup');
  };

  const isTestPage = () => {
  return window.location.pathname.toLowerCase().endsWith('/testing.asp');
};

  // ---------- PHA dos testes ----------
  // Coleta a linha: "Pontos de característica"
  // Ordem: Potência | Dirigibilidade | Aceleração

  function extractPha() {
    if (!isCarPage()) return null;

    const values = findRowTdValuesByHeader('Pontos de característica');

    if (!Array.isArray(values) || values.length < 3) return null;

    return {
      p: values[0] ?? 0,
      h: values[1] ?? 0,
      a: values[2] ?? 0
    };
  }

  // ---------- Extrator de Piloto ----------

  function extractDriver() {
    if (!isDriverPage()) return null;

    const data = {};

    const ids = {
      concentration: 'Conc',
      talent: 'Talent',
      aggression: 'Aggr',
      experience: 'Experience',
      technical_knowledge: 'TechI',
      endurance: 'Stamina',
      charisma: 'Charisma',
      motivation: 'Motivation'
    };

    for (const [field, id] of Object.entries(ids)) {
      const el = document.getElementById(id);

      if (el) {
        const v = textToInt(el);
        if (v !== null) data[field] = v;
      }
    }

    const camposTexto = {
      'Reputação': 'reputation',
      'Peso': 'weight_kg',
      'Idade': 'age'
    };

    for (const [label, field] of Object.entries(camposTexto)) {
      const v = findValueByLabel(label);
      if (v !== null) data[field] = v;
    }

    console.log('[ABR-FGG] Piloto extraído:', data);

    return Object.keys(data).length > 0 ? data : null;
  }

  // ---------- Extrator de Carro ----------

  function extractCar() {
    if (!isCarPage()) return null;

    const data = {};

    const selects = {
      chassis: 'BuyChassis',
      engine: 'BuyEngine',
      front_wing: 'BuyFWing',
      rear_wing: 'BuyRWing',
      underbody: 'BuyUnderbody',
      sidepods: 'BuySidepods',
      radiator: 'BuyCooling',
      gearbox: 'BuyGear',
      brakes: 'BuyBrakes',
      suspension: 'BuySusp',
      electronics: 'BuyElectronics'
    };

    for (const [field, selectId] of Object.entries(selects)) {
      const select = document.getElementById(selectId);
      if (!select) continue;

      const tr = select.closest('tr');
      if (!tr) continue;

      const tds = tr.querySelectorAll('td');

      if (tds[1]) {
        const lvl = textToInt(tds[1]);
        if (lvl !== null) data[`${field}_lvl`] = lvl;
      }

      if (tds[3]) {
        const wear = parseInt((tds[3].textContent || '').replace('%', ''), 10);
        if (!Number.isNaN(wear)) data[`${field}_wear`] = wear;
      }
    }

    console.log('[ABR-FGG] Carro extraído:', data);

    return Object.keys(data).length > 0 ? data : null;
  }

  function extractTestWeather() {
  if (!isTestPage()) return null;

  const h2 = Array.from(document.querySelectorAll('h2')).find((h) =>
    normalizeText(h.textContent).includes('clima atual')
  );

  if (!h2) return null;

  let table = h2.nextElementSibling;

  while (table && table.tagName !== 'TABLE') {
    table = table.nextElementSibling;
  }

  if (!table) return null;

  const cell = table.querySelector('td');

  if (!cell) return null;

  const tempMatch = (cell.textContent || '').match(/Temp:\s*(-?\d+)/);
  const temp = tempMatch ? parseInt(tempMatch[1], 10) : null;

  const img = cell.querySelector('img');

  const rainSource = [
    img?.title,
    img?.alt,
    img?.src,
    cell.textContent
  ]
    .filter(Boolean)
    .join(' ')
    .toLowerCase();

  const weather = /chuva|rain/.test(rainSource) ? 'chuva' : 'seco';

  return {
    temp,
    weather
  };
}

function extractTestCar() {
  if (!isTestPage()) return null;

  const header = Array.from(document.querySelectorAll('th')).find((th) =>
    normalizeText(th.textContent).includes('partes relacionadas aos ajustes')
  );

  const table = header?.closest('table');

  if (!table) return null;

  const partMap = [
    { match: 'asa dianteira', field: 'front_wing' },
    { match: 'asa traseira', field: 'rear_wing' },
    { match: 'motor', field: 'engine' },
    { match: 'freios', field: 'brakes' },
    { match: 'cambio', field: 'gearbox' },
    { match: 'suspensao', field: 'suspension' },
    { match: 'chassi', field: 'chassis' },
    { match: 'assoalho', field: 'underbody' },
    { match: 'laterais', field: 'sidepods' },
    { match: 'radiador', field: 'radiator' },
    { match: 'eletronicos', field: 'electronics' }
  ];

  const data = {};

  const rows = Array.from(table.querySelectorAll('tr'));

  rows.forEach((tr) => {
    const cells = Array.from(tr.querySelectorAll('td'));

    cells.forEach((cell, index) => {
      const label = normalizeText(cell.textContent);

      const part = partMap.find((p) => label.includes(p.match));

      if (!part) return;

      let level = null;
      let wear = null;

      for (let i = index + 1; i < cells.length; i++) {
        const txt = (cells[i].textContent || '').trim();

        if (level === null && /^\d+$/.test(txt.replace(/\s/g, ''))) {
          level = textToInt(cells[i]);
        } else if (wear === null && txt.includes('%')) {
          wear = parseWearText(txt);
        }

        if (level !== null && wear !== null) break;
      }

      if (level !== null) data[`${part.field}_lvl`] = level;
      if (wear !== null) data[`${part.field}_wear`] = wear;
    });
  });

  console.log('[ABR-FGG] Carro extraído da página de testes:', data);

  return Object.keys(data).length > 0 ? data : null;
}

  // ---------- Temperaturas dos 4 quadrantes (min e max) ----------

  function getRaceForecastTemps() {
    const h2 = Array.from(document.querySelectorAll('h2')).find((h) =>
      (h.textContent || '').includes('Previsão da corrida')
    );

    if (!h2) return [];

    let table = h2.nextElementSibling;

    while (table && table.tagName !== 'TABLE') {
      table = table.nextElementSibling;
    }

    if (!table) return [];

    // ordem dos <td>: 00-30, 30-60, 60-90, 90-120
    return Array.from(table.querySelectorAll('td')).map((td) => {
      const m = (td.textContent || '').match(/Temp:\s*(-?\d+)\s*°?\s*-\s*(-?\d+)/);

      return m
        ? { min: parseFloat(m[1]), max: parseFloat(m[2]) }
        : { min: null, max: null };
    });
  }

  // ---------- Voltas de treino ----------

  function createEmptyPracticeLap() {
    return {
      lap_time: 0,
      driver_error: 0,
      net_time: 0,
      fw: 0,
      rw: 0,
      engine: 0,
      brakes: 0,
      gear: 0,
      susp: 0,
      tyre_code: 0,
      tyre_name: '',
      comments: [],
      comment: ''
    };
  }

  function createEmptyPracticeLaps() {
    const laps = {};

    for (let i = 1; i <= 8; i++) {
      laps[`lap_${i}`] = createEmptyPracticeLap();
    }

    return laps;
  }

  // Converte o HTML do span #lapComments em lista de comentários
  function parseLapComments(container) {
    if (!container) return [];

    const temp = document.createElement('div');

    // Transforma <br> e fechamentos de tags em quebras de linha
    const html = String(container.innerHTML || '')
      .replace(/<br\s*\/?>/gi, '\n')
      .replace(/<\/font>/gi, '</font>\n')
      .replace(/<\/span>/gi, '</span>\n')
      .replace(/<\/div>/gi, '</div>\n')
      .replace(/<\/p>/gi, '</p>\n');

    temp.innerHTML = html;

    const text = temp.textContent || '';

    const lines = text
      .split(/\r?\n/)
      .map((line) =>
        line
          .replace(/\u00a0/g, ' ')
          .replace(/\s+/g, ' ')
          .trim()
      )
      .filter(Boolean);

    // Cada volta pode ter até 5 comentários
    return lines.slice(0, 5);
  }

  // Coleta os comentários de cada volta clicando nos radios
  function collectPracticeLapComments() {
    const comments = {};

    for (let i = 1; i <= 8; i++) {
      comments[`lap_${i}`] = [];
    }

    const lapCommentsEl = document.getElementById('lapComments');
    const radios = Array.from(
      document.querySelectorAll('input[name="rbLapComment"]')
    );

    if (!lapCommentsEl || radios.length === 0) {
      return comments;
    }

    const originalChecked = document.querySelector(
      'input[name="rbLapComment"]:checked'
    );

    const originalValue = originalChecked ? originalChecked.value : null;
    const initialCommentsHtml = lapCommentsEl.innerHTML;

    const lapNumberEl = document.getElementById('lapNumber');
    const initialLapNumber = lapNumberEl ? lapNumberEl.textContent : '';

    radios.forEach((radio) => {
      const lap = parseInt(radio.value, 10);

      if (!lap || lap < 1 || lap > 8) return;

      try {
        radio.click();

        comments[`lap_${lap}`] = parseLapComments(lapCommentsEl);
      } catch (e) {
        console.error(`[ABR-FGG] Erro ao coletar comentário da volta ${lap}:`, e);
      }
    });

    // Restaura a volta que estava selecionada antes
    try {
      if (originalValue != null) {
        const originalRadio = radios.find((r) => r.value === originalValue);

        if (originalRadio) {
          originalRadio.click();
        }
      } else {
        lapCommentsEl.innerHTML = initialCommentsHtml;

        if (lapNumberEl) {
          lapNumberEl.textContent = initialLapNumber;
        }
      }
    } catch (e) {
      console.warn('[ABR-FGG] Não foi possível restaurar o comentário selecionado.', e);
    }

    return comments;
  }

  function extractPracticeLaps() {
    const laps = createEmptyPracticeLaps();

    if (!isRacePage()) return laps;

    const header = Array.from(document.querySelectorAll('th')).find((th) =>
      normalizeText(th.textContent).includes('dados das voltas de treino')
    );

    if (!header) return laps;

    const table = header.closest('table');

    if (!table) return laps;

    const rows = Array.from(table.querySelectorAll('tr')).filter((tr) => {
      return tr.querySelectorAll('td').length >= 11;
    });

    rows.slice(0, 8).forEach((tr, index) => {
      const tds = tr.querySelectorAll('td');

      const lapNumber = textToInt(tds[0]) ?? index + 1;
      const key = `lap_${lapNumber}`;

      if (!laps[key]) return;

      laps[key] = {
        lap_time: parseLapTimeToSeconds(tds[1]?.textContent),
        driver_error: parseLapTimeToSeconds(tds[2]?.textContent),
        net_time: parseLapTimeToSeconds(tds[3]?.textContent),
        fw: textToInt(tds[4]) ?? 0,
        rw: textToInt(tds[5]) ?? 0,
        engine: textToInt(tds[6]) ?? 0,
        brakes: textToInt(tds[7]) ?? 0,
        gear: textToInt(tds[8]) ?? 0,
        susp: textToInt(tds[9]) ?? 0,
        tyre_code: tyreTextToCode(tds[10]?.textContent),
        tyre_name: tyreTextToLabel(tds[10]?.textContent),
        comments: [],
        comment: ''
      };
    });

    // Coleta comentários depois de montar as voltas
    const lapComments = collectPracticeLapComments();

    for (let i = 1; i <= 8; i++) {
      const key = `lap_${i}`;

      if (!laps[key]) continue;

      const arr = Array.isArray(lapComments[key]) ? lapComments[key] : [];

      laps[key].comments = arr;
      laps[key].comment = arr.join('\n');
    }

    console.log('[ABR-FGG] Voltas de treino extraídas:', laps);

    return laps;
  }

  // ---------- Extrator de Corrida ----------

  function extractRace() {
    if (!isRacePage()) return null;

    const data = {};

    // Nome da pista ("Estoril GP (Portugal)" -> "Estoril")
    const trackLink = document.querySelector('h2 a[href*="TrackDetails"]');

    if (trackLink) {
      data.track_name = (trackLink.textContent || '').split(' GP')[0].trim();
    }

    // Temperaturas Q1/Q2 (valor único)
    const cells = Array.from(document.querySelectorAll('td.center'))
      .map((td) => td.textContent || '')
      .filter((t) => t.includes('Temp:'));

    const grab = (t) => {
      const m = t.match(/Temp:\s*(-?\d+)/);
      return m ? parseFloat(m[1]) : null;
    };

    if (cells[0]) data.air_temp = grab(cells[0]); // Q1
    if (cells[1]) data.q2_temp = grab(cells[1]); // Q2

    // Clima pelas imagens de previsão
    const isRain = (img) => img && /chuva|rain/i.test(img.alt || '');

    const wQ = document.querySelector('img[name="WeatherQ"]');
    const wR = document.querySelector('img[name="WeatherR"]');

    if (wQ) data.q1_weather = isRain(wQ) ? 'chuva' : 'seco';
    if (wR) data.q2_weather = isRain(wR) ? 'chuva' : 'seco';

    // Previsão da corrida: 4 quadrantes min/max
    const forecast = getRaceForecastTemps();

    if (forecast.length >= 4) {
      data.race_temps = forecast.slice(0, 4);

      if (forecast[0].min != null && forecast[0].max != null) {
        data.race_temp = (forecast[0].min + forecast[0].max) / 2;
      }
    }

    // Voltas de treino + comentários
    data.practice_laps = extractPracticeLaps();

    console.log('[ABR-FGG] Corrida extraída:', data);

    return Object.keys(data).length > 0 ? data : null;
  }

  // ============================================================
// RACE ANALYSIS / TELEMETRIA
// ============================================================

const isRaceAnalysisPage = () =>
  window.location.pathname.toLowerCase().endsWith('/raceanalysis.asp');

function parseTimeToSecondsOrNull(text) {
  if (!text) return null;

  const clean = String(text).replace(/[^\d:.]/g, '').trim();

  if (!clean) return null;

  if (clean.includes(':')) {
    const parts = clean.split(':');

    const minutes = parseFloat(parts[0]);
    const seconds = parseFloat(parts[1]);

    if (Number.isNaN(minutes) || Number.isNaN(seconds)) return null;

    return Number((minutes * 60 + seconds).toFixed(3));
  }

  const value = parseFloat(clean);

  return Number.isNaN(value) ? null : Number(value.toFixed(3));
}

function parsePercentValue(text) {
  const match = String(text || '').match(/(\d+)\s*%/);

  return match ? parseInt(match[1], 10) : null;
}

function mostCommonValue(values) {
  const filtered = values.filter((v) => v != null && v !== '');

  if (!filtered.length) return null;

  const counts = {};
  let best = filtered[0];
  let bestCount = 0;

  filtered.forEach((value) => {
    const key = String(value);

    counts[key] = (counts[key] || 0) + 1;

    if (counts[key] > bestCount) {
      bestCount = counts[key];
      best = value;
    }
  });

  return best;
}

function findTableByHeaderText(headerText) {
  const target = normalizeText(headerText);

  return Array.from(document.querySelectorAll('table')).find((table) => {
    return Array.from(table.querySelectorAll('th, td')).some((cell) =>
      normalizeText(cell.textContent).includes(target)
    );
  });
}

function tyreLabelToCode(label) {
  const t = normalizeText(label || '')
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();

  if (t.includes('super macio')) return 1;
  if (t.includes('macio')) return 2;
  if (t.includes('medio')) return 3;
  if (t.includes('duro')) return 4;
  if (t.includes('chuva')) return 6;

  return 0;
}

// ---------- Meta: temporada, corrida, pista, grupo ----------

function extractRaceAnalysisMeta() {
  const params = new URLSearchParams(window.location.search);

  let season = parseInt(params.get('S') || '', 10);
  let raceNumber = null;

  const sr = params.get('SR') || '';

  if (sr.includes(',')) {
    const parts = sr.split(',');

    const s = parseInt(parts[0], 10);
    const r = parseInt(parts[1], 10);

    if (!Number.isNaN(s)) season = s;
    if (!Number.isNaN(r)) raceNumber = r;
  }

  if (Number.isNaN(season)) {
    const seasonMatch = document.title.match(/Temporada\s*(\d+)/i);
    if (seasonMatch) season = parseInt(seasonMatch[1], 10);
  }

  if (raceNumber == null) {
    const raceMatch = document.title.match(/Corrida\s*(\d+)/i);
    if (raceMatch) raceNumber = parseInt(raceMatch[1], 10);
  }

  const h1 = document.querySelector('h1.block');

  let trackName = null;
  let gproTrackId = null;
  let groupName = null;

  const trackLink = h1?.querySelector('a[href*="TrackDetails"]');

  if (trackLink) {
    trackName = (trackLink.textContent || '')
      .split('(')[0]
      .trim();

    const href = trackLink.getAttribute('href') || '';
    const idMatch = href.match(/[?&]id=(\d+)/i);

    if (idMatch) {
      gproTrackId = parseInt(idMatch[1], 10);
    }
  }

  if (h1) {
    const parentheses = [...h1.textContent.matchAll(/\(([^()]+)\)/g)];

    if (parentheses.length > 0) {
      groupName = parentheses[parentheses.length - 1][1].trim();
    }
  }

  return {
    season: Number.isNaN(season) ? null : season,
    race_number: raceNumber,
    track_name: trackName,
    gpro_track_id: gproTrackId,
    group_name: groupName,
    url: window.location.href
  };
}

// ---------- Q1 / Q2 ----------

function extractQualifyingTimes() {
  const table = findTableByHeaderText('tempo das voltas');

  if (!table) return null;

  const result = {
    q1_time_text: null,
    q1_seconds: null,
    q1_position: null,
    q2_time_text: null,
    q2_seconds: null,
    q2_position: null
  };

  function parseCell(td, prefix) {
    const text = (td?.textContent || '').trim();

    if (!text) return;

    const timePart = text.split('(')[0].trim();

    result[`${prefix}_time_text`] = text;
    result[`${prefix}_seconds`] = parseTimeToSecondsOrNull(timePart);

    const posMatch = text.match(/#(\d+)/);

    if (posMatch) {
      result[`${prefix}_position`] = parseInt(posMatch[1], 10);
    }
  }

  const rows = Array.from(table.querySelectorAll('tr'));

  rows.forEach((tr) => {
    const tds = tr.querySelectorAll('td');

    if (tds.length >= 2) {
      parseCell(tds[0], 'q1');
      parseCell(tds[1], 'q2');
    }
  });

  return result;
}

// ---------- Setups usados ----------

function extractRaceAnalysisSetups() {
  const table = findTableByHeaderText('ajustes usados');

  if (!table) return null;

  const setups = {};

  Array.from(table.querySelectorAll('tr')).forEach((tr) => {
    const tds = tr.querySelectorAll('td');

    if (tds.length < 8) return;

    const sessionText = normalizeText(tds[0].textContent);

    if (!sessionText || sessionText.includes('sessao')) return;

    let key = sessionText;

    if (sessionText.includes('q1')) key = 'q1';
    else if (sessionText.includes('q2')) key = 'q2';
    else if (sessionText.includes('corrida')) key = 'race';

    setups[key] = {
      front_wing: textToInt(tds[1]),
      rear_wing: textToInt(tds[2]),
      engine: textToInt(tds[3]),
      brakes: textToInt(tds[4]),
      gearbox: textToInt(tds[5]),
      suspension: textToInt(tds[6]),
      tyre: (tds[7]?.textContent || '').trim(),
      tyre_code: tyreLabelToCode(tds[7]?.textContent)
    };
  });

  return Object.keys(setups).length > 0 ? setups : null;
}

// ---------- Riscos ----------

function extractRaceRisks() {
  const table = findTableByHeaderText('riscos usados');

  if (!table) return null;

  const tdEls = Array.from(table.querySelectorAll('td')).filter(
    (td) => !td.querySelector('table')
  );

  const texts = tdEls
    .map((td) => td.textContent.trim())
    .filter(Boolean);

  const data = {
    q1_risk: null,
    q2_risk: null,
    start_risk: null,
    values: {
      overtake: null,
      defend: null,
      clean_dry: null,
      clean_wet: null,
      failure: null
    }
  };

  if (texts.length >= 3) {
    data.q1_risk = texts[0];
    data.q2_risk = texts[1];
    data.start_risk = texts[2];
  }

  const nums = texts
    .slice(3)
    .map((t) => textToInt({ textContent: t }))
    .filter((v) => v !== null);

  if (nums.length >= 5) {
    data.values = {
      overtake: nums[0],
      defend: nums[1],
      clean_dry: nums[2],
      clean_wet: nums[3],
      failure: nums[4]
    };
  }

  return data;
}

// ---------- Energia ----------

function extractRaceEnergy() {
  const table = findTableByHeaderText('energia do piloto');

  if (!table) return null;

  const percents = Array.from(table.querySelectorAll('.barLabel')).map((el) =>
    parsePercentValue(el.textContent)
  );

  return {
    q1: {
      before_percent: percents[0] ?? null,
      after_percent: percents[1] ?? null
    },
    q2: {
      before_percent: percents[2] ?? null,
      after_percent: percents[3] ?? null
    },
    race: {
      before_percent: percents[4] ?? null,
      after_percent: percents[5] ?? null
    }
  };
}

// ---------- Posições ----------

function extractRacePositions() {
  const table = findTableByHeaderText('posições');

  if (!table) return null;

  let startPosition = null;
  let finishPosition = null;

  Array.from(table.querySelectorAll('tr')).forEach((tr) => {
    const tds = tr.querySelectorAll('td');

    if (tds.length === 2) {
      startPosition = textToInt(tds[0]);
      finishPosition = textToInt(tds[1]);
    }
  });

  return {
    start_position: startPosition,
    finish_position: finishPosition
  };
}

// ---------- Característica do carro ----------

function extractCarCharacteristic() {
  const table = findTableByHeaderText('média da característica do carro');

  if (!table) return null;

  const rows = Array.from(table.querySelectorAll('tr'));

  for (const tr of rows) {
    const tds = tr.querySelectorAll('td');

    if (tds.length === 3) {
      return {
        power: textToInt(tds[0]),
        handling: textToInt(tds[1]),
        acceleration: textToInt(tds[2])
      };
    }
  }

  return null;
}

// ---------- Fornecedor de pneus ----------

function extractTyreSupplier() {
  const table = findTableByHeaderText('fornecedor de pneus');

  if (!table) return null;

  const nameCell = Array.from(table.querySelectorAll('td')).find((td) => {
    return (
      !td.querySelector('table') &&
      (td.querySelector('img[title], img[alt]') || td.querySelector('b'))
    );
  });

  let name = null;

  if (nameCell) {
    name =
      nameCell.querySelector('b')?.textContent?.trim() ||
      nameCell.querySelector('img')?.title ||
      nameCell.querySelector('img')?.alt ||
      nameCell.textContent.trim();
  }

  const peakMatch = (table.innerText || '').match(
    /Temperatura de pico:\s*(\d+)/i
  );

  const titles = Array.from(table.querySelectorAll('td[title]'))
    .map((td) => parseInt(td.getAttribute('title'), 10))
    .filter((v) => !Number.isNaN(v));

  return {
    name,
    peak_temp_c: peakMatch ? parseInt(peakMatch[1], 10) : null,
    dry_performance: titles[0] ?? null,
    wet_performance: titles[1] ?? null,
    durability: titles[2] ?? null,
    warmup_distance: titles[3] ?? null
  };
}

// ---------- Desgaste do carro ----------

function extractRaceCarWear() {
  const table = findTableByHeaderText('nível das partes do carro');

  if (!table) return null;

  const partKeys = [
    'chassis',
    'engine',
    'front_wing',
    'rear_wing',
    'underbody',
    'sidepods',
    'radiator',
    'gearbox',
    'brakes',
    'suspension',
    'electronics'
  ];

  const data = {
    levels: {},
    wear_start: {},
    wear_end: {}
  };

  let current = null;

  Array.from(table.querySelectorAll('tr')).forEach((tr) => {
    const th = tr.querySelector('th');

    if (th && th.colSpan === 11) {
      const title = normalizeText(th.textContent);

      if (title.includes('nivel das partes')) {
        current = 'levels';
      } else if (title.includes('desgaste das partes') && title.includes('inicio')) {
        current = 'wear_start';
      } else if (title.includes('desgaste das partes') && title.includes('final')) {
        current = 'wear_end';
      }

      return;
    }

    if (!current) return;

    const tds = tr.querySelectorAll('td');

    if (tds.length >= 11) {
      partKeys.forEach((key, index) => {
        if (current === 'levels') {
          data[current][key] = textToInt(tds[index]);
        } else {
          data[current][key] = parsePercentValue(tds[index]?.textContent);
        }
      });
    }
  });

  return data;
}

// ---------- Atributos do piloto ----------

function extractRaceDriverAttributes() {
  const table = findTableByHeaderText('atributos do piloto');

  if (!table) return null;

  const nameLink = table.querySelector('a[href*="DriverProfile"]');

  const rows = Array.from(table.querySelectorAll('tr'));

  let beforeRow = null;
  let deltaRow = null;

  rows.forEach((tr) => {
    const tds = tr.querySelectorAll('td');

    if (tds.length >= 11) {
      if (!beforeRow) beforeRow = tr;
      else deltaRow = tr;
    }
  });

  function parseRow(tr) {
    if (!tr) return null;

    const tds = tr.querySelectorAll('td');

    const values = Array.from(tds).map((td) => td.textContent.trim());

    const hasName = Boolean(tr.querySelector('a[href*="DriverProfile"]'));
    const startIndex = hasName ? 1 : 0;

    const nums = values
      .slice(startIndex, startIndex + 11)
      .map((value) => {
        const match = value.match(/([+-]?\d+)/);
        return match ? parseInt(match[1], 10) : null;
      });

    return {
      total: nums[0] ?? null,
      concentration: nums[1] ?? null,
      talent: nums[2] ?? null,
      aggression: nums[3] ?? null,
      experience: nums[4] ?? null,
      technical_knowledge: nums[5] ?? null,
      endurance: nums[6] ?? null,
      charisma: nums[7] ?? null,
      motivation: nums[8] ?? null,
      reputation: nums[9] ?? null,
      weight: nums[10] ?? null
    };
  }

  return {
    name: nameLink?.textContent?.trim() || null,
    before: parseRow(beforeRow),
    delta: parseRow(deltaRow)
  };
}

// ---------- Voltas da corrida ----------

function extractRaceLaps() {
  const table = Array.from(document.querySelectorAll('table')).find((tbl) => {
    const firstRow = tbl.querySelector('tr');

    if (!firstRow) return false;

    const text = normalizeText(firstRow.textContent);

    return (
      text.includes('volta') &&
      text.includes('tempo de volta') &&
      text.includes('pos') &&
      text.includes('pneus') &&
      text.includes('clima') &&
      text.includes('temp') &&
      text.includes('umi') &&
      text.includes('eventos')
    );
  });

  if (!table) return [];

  const laps = [];

  Array.from(table.querySelectorAll('tr')).forEach((tr) => {
    const tds = tr.querySelectorAll('td');

    if (tds.length < 8) return;

    const lap = textToInt(tds[0]);

    if (lap == null) return;

    const timeText = (tds[1]?.textContent || '').trim();

    const rawTyre = tds[3]?.textContent || '';
    const tyreWorn = /\(w\)/i.test(rawTyre);
    const tyreText = rawTyre
      .replace(/\(w\)/gi, '')
      .replace(/\s+/g, ' ')
      .trim();

    const weatherText = (tds[4]?.textContent || '').trim();
    const eventText = (tds[7]?.textContent || '').trim();

    laps.push({
      lap,
      time_text: timeText === '-' ? null : timeText,
      time_seconds: parseTimeToSecondsOrNull(timeText),
      position: textToInt(tds[2]),
      tyre: tyreText,
      tyre_code: tyreLabelToCode(tyreText),
      tyre_worn: tyreWorn,
      weather: weatherText,
      weather_is_rain: /chuva|rain/i.test(weatherText),
      temp_c: textToInt(tds[5]),
      humidity_percent: parsePercentValue(tds[6]?.textContent),
      event: eventText === '-' ? null : eventText,
      event_pit: /pit/i.test(eventText)
    });
  });

  return laps;
}

// ---------- Pit stops ----------

function extractRacePitStops() {
  const table = findTableByHeaderText('razão do pitstop');

  if (!table) return [];

  const pitStops = [];

  Array.from(table.querySelectorAll('tr')).forEach((tr) => {
    const tds = tr.querySelectorAll('td');

    if (tds.length < 6) return;

    const firstCell = normalizeText(tds[0]?.textContent || '').replace(
      /\u00a0/g,
      ' '
    );

    const stopMatch = firstCell.match(/parada\s*(\d+)/);
    const lapMatch = firstCell.match(/volta\s*(\d+)/);

    pitStops.push({
      stop: stopMatch ? parseInt(stopMatch[1], 10) : null,
      lap: lapMatch ? parseInt(lapMatch[1], 10) : null,
      reason: (tds[1]?.textContent || '').trim(),
      tyre_condition_percent: parsePercentValue(tds[2]?.textContent),
      fuel_remaining_percent: parsePercentValue(tds[3]?.textContent),
      refueled_to_liters: textToInt(tds[4]),
      pit_time_text: (tds[5]?.textContent || '').trim(),
      pit_time_seconds: parseTimeToSecondsOrNull(tds[5]?.textContent)
    });
  });

  return pitStops;
}

// ---------- Combustível e pneus finais ----------

function extractRaceFuelAndFinalTyres() {
  const bodyText = document.body.innerText || '';

  const initialFuelMatch = bodyText.match(/Combustível inicial:\s*(\d+)/i);
  const finalFuelMatch = bodyText.match(
    /Combustível ao final da corrida:\s*(\d+)/i
  );
  const finalTyreMatch = bodyText.match(
    /Condição dos pneus no final:\s*(\d+)%/i
  );

  return {
    initial_fuel_liters: initialFuelMatch
      ? parseInt(initialFuelMatch[1], 10)
      : null,
    final_fuel_liters: finalFuelMatch
      ? parseInt(finalFuelMatch[1], 10)
      : null,
    final_tyre_condition_percent: finalTyreMatch
      ? parseInt(finalTyreMatch[1], 10)
      : null
  };
}

// ---------- Ultrapassagens ----------

function extractRaceOvertakes() {
  const table = findTableByHeaderText('tentativas de ultrapassagens iniciadas');

  if (!table) return null;

  const data = {};

  Array.from(table.querySelectorAll('tr')).forEach((tr) => {
    const th = tr.querySelector('th');
    const tds = tr.querySelectorAll('td');

    if (!th || tds.length < 2) return;

    const label = normalizeText(th.textContent);

    const blocked = textToInt(tds[0]);
    const success = textToInt(tds[1]);

    if (label.includes('iniciadas')) {
      data.initiated = {
        blocked,
        success
      };
    }

    if (label.includes('em voce')) {
      data.received = {
        blocked,
        success
      };
    }
  });

  return Object.keys(data).length > 0 ? data : null;
}

// ---------- Cálculo de stints ----------

function calculateRaceStints(laps, pitStops, finalInfo) {
  const raceLaps = laps.filter((lap) => lap.lap > 0);

  if (!raceLaps.length) return [];

  const maxLap = Math.max(...raceLaps.map((lap) => lap.lap));

  const pitLaps = (pitStops || [])
    .filter((pit) => pit.lap != null && pit.lap > 0)
    .sort((a, b) => a.lap - b.lap);

  const stints = [];

  function average(values) {
    const valid = values.filter((v) => v != null);

    if (!valid.length) return null;

    const sum = valid.reduce((acc, value) => acc + value, 0);

    return Number((sum / valid.length).toFixed(3));
  }

  function buildStint(startLap, endLap, pit, isFinal) {
    const stintLaps = raceLaps.filter(
      (lap) => lap.lap >= startLap && lap.lap <= endLap
    );

    const compound = mostCommonValue(stintLaps.map((lap) => lap.tyre));

    const compoundCode = mostCommonValue(
      stintLaps.map((lap) => lap.tyre_code).filter((v) => v != null)
    );

    const dominantWeather = mostCommonValue(
      stintLaps.map((lap) => lap.weather)
    );

    const tempAvg = average(stintLaps.map((lap) => lap.temp_c));
    const humidityAvg = average(stintLaps.map((lap) => lap.humidity_percent));

    const tyreConditionEnd = pit
      ? pit.tyre_condition_percent
      : finalInfo?.final_tyre_condition_percent ?? null;

    return {
      stint: stints.length + 1,
      laps_start: startLap,
      laps_end: endLap,
      lap_count: endLap - startLap + 1,

      compound,
      compound_code: compoundCode,

      dominant_weather: dominantWeather,

      temp_avg_c: tempAvg,
      humidity_avg_percent: humidityAvg,

      end_reason: pit ? pit.reason : 'Fim da corrida',

      pit_lap: pit ? pit.lap : null,
      pit_time_seconds: pit ? pit.pit_time_seconds : null,

      tyre_condition_start_percent: 100,
      tyre_condition_end_percent: tyreConditionEnd,
      tyre_wear_percent:
        tyreConditionEnd != null ? 100 - tyreConditionEnd : null,

      fuel_remaining_percent_at_end: pit ? pit.fuel_remaining_percent : null,
      refuel_to_liters: pit ? pit.refueled_to_liters : null,

      final_fuel_liters: isFinal ? finalInfo?.final_fuel_liters ?? null : null,
      final_tyre_condition_percent: isFinal
        ? finalInfo?.final_tyre_condition_percent ?? null
        : null,

      // Estes campos dependem de variáveis externas, calcular no sistema:
      // track_length_km, fuel_tank_capacity_liters, tyre model, etc.
      distance_km: null,
      fuel_used_liters: null,
      fuel_efficiency_km_per_liter: null,
      tyre_used_km: null,
      tyre_no_bad_km: null,
      tyre_total_km: null
    };
  }

  let currentStart = 1;

  pitLaps.forEach((pit) => {
    const end = Math.min(pit.lap, maxLap);

    if (end >= currentStart) {
      stints.push(buildStint(currentStart, end, pit, false));
      currentStart = end + 1;
    }
  });

  if (currentStart <= maxLap) {
    stints.push(buildStint(currentStart, maxLap, null, true));
  }

  return stints;
}

// ---------- Objeto final da telemetria ----------

function extractRaceAnalysis() {
  if (!isRaceAnalysisPage()) return null;

  const meta = extractRaceAnalysisMeta();

  const laps = extractRaceLaps();
  const pitStops = extractRacePitStops();
  const fuel = extractRaceFuelAndFinalTyres();

  const stints = calculateRaceStints(laps, pitStops, fuel);

  return {
    meta,

    track: {
      name: meta.track_name,
      gpro_track_id: meta.gpro_track_id,
      length_km: null
    },

    qualifying: extractQualifyingTimes(),
    setups: extractRaceAnalysisSetups(),
    risks: extractRaceRisks(),
    energy: extractRaceEnergy(),

    tyre_supplier: extractTyreSupplier(),

    car_characteristic: extractCarCharacteristic(),
    car: extractRaceCarWear(),

    driver: extractRaceDriverAttributes(),

    race: {
      positions: extractRacePositions(),
      fuel,
      overtakes: extractRaceOvertakes(),

      laps,
      pit_stops: pitStops,
      stints
    }
  };
}

  // ---------- API exposta ----------

  window.ABR_FGG_COLLECTOR = {
    collect() {
      let pageType = 'unknown';

      if (isDriverPage()) pageType = 'driver';
      else if (isCarPage()) pageType = 'car';
      else if (isRacePage()) pageType = 'race';
      else if (isTestPage()) pageType = 'test';
      else if (isRaceAnalysisPage()) pageType = 'race_analysis';

      console.log('[ABR-FGG] collect() chamado. pageType:', pageType);

      const result = {
  url: window.location.href,
  pageType,
  collectedAt: new Date().toISOString(),
  driver: null,
  car: null,
  race: null,
  pha: null,
  test: null,
  race_analysis: null
};

      try {
        result.driver = extractDriver();
      } catch (e) {
        console.error('Erro piloto:', e);
      }

      try {
        result.car = extractCar();
      } catch (e) {
        console.error('Erro carro:', e);
      }

      try {
        result.race = extractRace();
      } catch (e) {
        console.error('Erro corrida:', e);
      }

      try {
        result.pha = extractPha();
      } catch (e) {
        console.error('Erro PHA:', e);
      }

      try {
  if (isTestPage()) {
    result.test = extractTestWeather();

    const testCar = extractTestCar();

    if (testCar) {
      result.car = testCar;
    }
  }
} catch (e) {
  console.error('Erro testes:', e);
}

try {
  result.race_analysis = extractRaceAnalysis();
} catch (e) {
  console.error('Erro telemetria:', e);
}

      if (pageType === 'driver' && !result.driver) {
        result.error = 'Página do piloto detectada, mas nenhum dado lido.';
      }

      if (pageType === 'car' && !result.car && !result.pha) {
        result.error = 'Página do carro detectada, mas nenhum dado lido.';
      }

      if (pageType === 'race' && !result.race) {
        result.error = 'Página de corrida detectada, mas nenhum dado lido.';
      }

      if (pageType === 'test' && !result.test && !result.car) {
  result.error = 'Página de testes detectada, mas nenhum dado lido.';
}

 if (pageType === 'race_analysis' && !result.race_analysis) {
  result.error = 'Página de análise detectada, mas nenhuma telemetria lida.';
}

      console.log('[ABR-FGG] Resultado final:', result);

      return result;
    }
  };

 

  console.log('[ABR-FGG] API pronta. Teste: window.ABR_FGG_COLLECTOR.collect()');

  // ---------- Listener para o popup ----------

  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
      if (msg.type === 'COLLECT') {
        const result = window.ABR_FGG_COLLECTOR.collect();
        sendResponse(result);
      }

      return true;
    });

    try {
      chrome.runtime.sendMessage({
        type: 'CONTENT_READY',
        url: window.location.href
      });
    } catch (e) {
      console.warn('[ABR-FGG] Contexto da extensão inválido (recarregue a página).');
    }
  }
})();