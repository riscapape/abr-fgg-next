(() => {
  console.log('[ABR-FGG] content.js carregado em:', window.location.href);

  // ---------- Utilitários ----------

  function normalizeText(text) {
    return (text || '')
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/\s+/g, ' ')
      .trim()
      .toLowerCase();
  }

  function textToInt(el) {
    if (!el) return null;

    const txt = (el.textContent || '').replace(/[^\d-]/g, '');
    const n = parseInt(txt, 10);

    return Number.isNaN(n) ? null : n;
  }

  // Converte "2:16.355s" ou "1.389s" para segundos
  function parseLapTimeToSeconds(text) {
    if (!text) return 0;

    const clean = String(text).replace(/[^\d:.]/g, '').trim();

    if (!clean) return 0;

    if (clean.includes(':')) {
      const parts = clean.split(':');

      const minutes = parseFloat(parts[0]);
      const seconds = parseFloat(parts[1]);

      if (Number.isNaN(minutes) || Number.isNaN(seconds)) return 0;

      return Number((minutes * 60 + seconds).toFixed(3));
    }

    const value = parseFloat(clean);

    return Number.isNaN(value) ? 0 : Number(value.toFixed(3));
  }

  // Converte texto do pneu para código numérico
  function tyreTextToCode(text) {
    const t = normalizeText(text || '')
      .replace(/[^a-z0-9]+/g, ' ')
      .trim();

    if (t.includes('super macio')) return 1;
    if (t.includes('macio')) return 2;
    if (t.includes('medio')) return 3;
    if (t.includes('duro')) return 4;
    if (t.includes('chuva')) return 6;

    return 0;
  }

  // Valor pelo texto do <th> vizinho (Reputação, Peso, Idade, Total)
  function findValueByLabel(labelContains) {
    const ths = document.querySelectorAll('th');

    for (const th of ths) {
      const txt = (th.textContent || '').trim();

      if (txt.includes(labelContains)) {
        const tr = th.closest('tr');

        if (tr) {
          const tds = tr.querySelectorAll('td');

          for (let i = tds.length - 1; i >= 0; i--) {
            const v = textToInt(tds[i]);
            if (v !== null) return v;
          }
        }
      }
    }

    return null;
  }

  // Procura uma linha pelo título do <th> e retorna os valores dos <td>
  function findRowTdValuesByHeader(headerText) {
    const target = normalizeText(headerText);
    const rows = document.querySelectorAll('tr');

    for (const tr of rows) {
      const ths = tr.querySelectorAll('th');

      const found = Array.from(ths).some((th) =>
        normalizeText(th.textContent).includes(target)
      );

      if (!found) continue;

      const tds = tr.querySelectorAll('td');
      const values = Array.from(tds).map((td) => textToInt(td));

      if (values.length > 0) return values;
    }

    return [];
  }

  // ---------- Detectores de página ----------

  const isDriverPage = () =>
    window.location.href.toLowerCase().includes('driverprofile');

  const isCarPage = () =>
    window.location.href.toLowerCase().includes('updatecar');

  const isRacePage = () => {
    const u = window.location.href.toLowerCase();
    return u.includes('qualify') || u.includes('racesetup');
  };

  // ---------- PHA dos testes ----------
  // Coleta a linha: "Pontos de característica"
  // Ordem: Potência | Dirigibilidade | Aceleração

  function extractPha() {
    if (!isCarPage()) return null;

    const values = findRowTdValuesByHeader('Pontos de característica');

    if (!Array.isArray(values) || values.length < 3) return null;

    return {
      p: values[0] ?? 0,
      h: values[1] ?? 0,
      a: values[2] ?? 0
    };
  }

  // ---------- Extrator de Piloto ----------

  function extractDriver() {
    if (!isDriverPage()) return null;

    const data = {};

    const ids = {
      concentration: 'Conc',
      talent: 'Talent',
      aggression: 'Aggr',
      experience: 'Experience',
      technical_knowledge: 'TechI',
      endurance: 'Stamina',
      charisma: 'Charisma',
      motivation: 'Motivation'
    };

    for (const [field, id] of Object.entries(ids)) {
      const el = document.getElementById(id);

      if (el) {
        const v = textToInt(el);
        if (v !== null) data[field] = v;
      }
    }

    const camposTexto = {
      'Reputação': 'reputation',
      'Peso': 'weight_kg',
      'Idade': 'age'
    };

    for (const [label, field] of Object.entries(camposTexto)) {
      const v = findValueByLabel(label);
      if (v !== null) data[field] = v;
    }

    console.log('[ABR-FGG] Piloto extraído:', data);

    return Object.keys(data).length > 0 ? data : null;
  }

  // ---------- Extrator de Carro ----------

  function extractCar() {
    if (!isCarPage()) return null;

    const data = {};

    const selects = {
      chassis: 'BuyChassis',
      engine: 'BuyEngine',
      front_wing: 'BuyFWing',
      rear_wing: 'BuyRWing',
      underbody: 'BuyUnderbody',
      sidepods: 'BuySidepods',
      radiator: 'BuyCooling',
      gearbox: 'BuyGear',
      brakes: 'BuyBrakes',
      suspension: 'BuySusp',
      electronics: 'BuyElectronics'
    };

    for (const [field, selectId] of Object.entries(selects)) {
      const select = document.getElementById(selectId);
      if (!select) continue;

      const tr = select.closest('tr');
      if (!tr) continue;

      const tds = tr.querySelectorAll('td');

      if (tds[1]) {
        const lvl = textToInt(tds[1]);
        if (lvl !== null) data[`${field}_lvl`] = lvl;
      }

      if (tds[3]) {
        const wear = parseInt((tds[3].textContent || '').replace('%', ''), 10);
        if (!Number.isNaN(wear)) data[`${field}_wear`] = wear;
      }
    }

    console.log('[ABR-FGG] Carro extraído:', data);

    return Object.keys(data).length > 0 ? data : null;
  }

  // ---------- Temperaturas dos 4 quadrantes (min e max) ----------

  function getRaceForecastTemps() {
    const h2 = Array.from(document.querySelectorAll('h2')).find((h) =>
      (h.textContent || '').includes('Previsão da corrida')
    );

    if (!h2) return [];

    let table = h2.nextElementSibling;

    while (table && table.tagName !== 'TABLE') {
      table = table.nextElementSibling;
    }

    if (!table) return [];

    // ordem dos <td>: 00-30, 30-60, 60-90, 90-120
    return Array.from(table.querySelectorAll('td')).map((td) => {
      const m = (td.textContent || '').match(/Temp:\s*(-?\d+)\s*°?\s*-\s*(-?\d+)/);

      return m
        ? { min: parseFloat(m[1]), max: parseFloat(m[2]) }
        : { min: null, max: null };
    });
  }

  // ---------- Voltas de treino ----------

  function createEmptyPracticeLap() {
    return {
      lap_time: 0,
      driver_error: 0,
      net_time: 0,
      fw: 0,
      rw: 0,
      engine: 0,
      brakes: 0,
      gear: 0,
      susp: 0,
       tyre_code: 0,
    tyre_name: ''
    };
  }

  function tyreTextToLabel(text) {
  return (text || '').trim();
}

  function createEmptyPracticeLaps() {
    const laps = {};

    for (let i = 1; i <= 8; i++) {
      laps[`lap_${i}`] = createEmptyPracticeLap();
    }

    return laps;
  }

  function extractPracticeLaps() {
    const laps = createEmptyPracticeLaps();

    if (!isRacePage()) return laps;

    const header = Array.from(document.querySelectorAll('th')).find((th) =>
      normalizeText(th.textContent).includes('dados das voltas de treino')
    );

    if (!header) return laps;

    const table = header.closest('table');

    if (!table) return laps;

    const rows = Array.from(table.querySelectorAll('tr')).filter((tr) => {
      return tr.querySelectorAll('td').length >= 11;
    });

    rows.slice(0, 8).forEach((tr, index) => {
      const tds = tr.querySelectorAll('td');

      const lapNumber = textToInt(tds[0]) ?? index + 1;
      const key = `lap_${lapNumber}`;

      if (!laps[key]) return;

        laps[key] = {
      lap_time: parseLapTimeToSeconds(tds[1]?.textContent),
      driver_error: parseLapTimeToSeconds(tds[2]?.textContent),
      net_time: parseLapTimeToSeconds(tds[3]?.textContent),
      fw: textToInt(tds[4]) ?? 0,
      rw: textToInt(tds[5]) ?? 0,
      engine: textToInt(tds[6]) ?? 0,
      brakes: textToInt(tds[7]) ?? 0,
      gear: textToInt(tds[8]) ?? 0,
      susp: textToInt(tds[9]) ?? 0,
      tyre_code: tyreTextToCode(tds[10]?.textContent),
      tyre_name: tyreTextToLabel(tds[10]?.textContent)
    };
    });

    console.log('[ABR-FGG] Voltas de treino extraídas:', laps);

    return laps;
  }

  // ---------- Extrator de Corrida ----------

  function extractRace() {
    if (!isRacePage()) return null;

    const data = {};

    // Nome da pista ("Estoril GP (Portugal)" -> "Estoril")
    const trackLink = document.querySelector('h2 a[href*="TrackDetails"]');

    if (trackLink) {
      data.track_name = (trackLink.textContent || '').split(' GP')[0].trim();
    }

    // Temperaturas Q1/Q2 (valor único)
    const cells = Array.from(document.querySelectorAll('td.center'))
      .map((td) => td.textContent || '')
      .filter((t) => t.includes('Temp:'));

    const grab = (t) => {
      const m = t.match(/Temp:\s*(-?\d+)/);
      return m ? parseFloat(m[1]) : null;
    };

    if (cells[0]) data.air_temp = grab(cells[0]); // Q1
    if (cells[1]) data.q2_temp = grab(cells[1]); // Q2

    // Clima pelas imagens de previsão
    const isRain = (img) => img && /chuva|rain/i.test(img.alt || '');

    const wQ = document.querySelector('img[name="WeatherQ"]');
    const wR = document.querySelector('img[name="WeatherR"]');

    if (wQ) data.q1_weather = isRain(wQ) ? 'chuva' : 'seco';
    if (wR) data.q2_weather = isRain(wR) ? 'chuva' : 'seco';

    // Previsão da corrida: 4 quadrantes min/max
    const forecast = getRaceForecastTemps();

    if (forecast.length >= 4) {
      data.race_temps = forecast.slice(0, 4);

      if (forecast[0].min != null && forecast[0].max != null) {
        data.race_temp = (forecast[0].min + forecast[0].max) / 2;
      }
    }

    // Voltas de treino
    data.practice_laps = extractPracticeLaps();

    console.log('[ABR-FGG] Corrida extraída:', data);

    return Object.keys(data).length > 0 ? data : null;
  }

  // ---------- API exposta ----------

  window.ABR_FGG_COLLECTOR = {
    collect() {
      let pageType = 'unknown';

      if (isDriverPage()) pageType = 'driver';
      else if (isCarPage()) pageType = 'car';
      else if (isRacePage()) pageType = 'race';

      console.log('[ABR-FGG] collect() chamado. pageType:', pageType);

      const result = {
        url: window.location.href,
        pageType,
        collectedAt: new Date().toISOString(),
        driver: null,
        car: null,
        race: null,
        pha: null
      };

      try {
        result.driver = extractDriver();
      } catch (e) {
        console.error('Erro piloto:', e);
      }

      try {
        result.car = extractCar();
      } catch (e) {
        console.error('Erro carro:', e);
      }

      try {
        result.race = extractRace();
      } catch (e) {
        console.error('Erro corrida:', e);
      }

      try {
        result.pha = extractPha();
      } catch (e) {
        console.error('Erro PHA:', e);
      }

      if (pageType === 'driver' && !result.driver) {
        result.error = 'Página do piloto detectada, mas nenhum dado lido.';
      }

      if (pageType === 'car' && !result.car && !result.pha) {
        result.error = 'Página do carro detectada, mas nenhum dado lido.';
      }

      if (pageType === 'race' && !result.race) {
        result.error = 'Página de corrida detectada, mas nenhum dado lido.';
      }

      console.log('[ABR-FGG] Resultado final:', result);

      return result;
    }
  };

  console.log('[ABR-FGG] API pronta. Teste: window.ABR_FGG_COLLECTOR.collect()');

  // ---------- Listener para o popup ----------

  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
      if (msg.type === 'COLLECT') {
        const result = window.ABR_FGG_COLLECTOR.collect();
        sendResponse(result);
      }

      return true;
    });

    try {
      chrome.runtime.sendMessage({
        type: 'CONTENT_READY',
        url: window.location.href
      });
    } catch (e) {
      console.warn('[ABR-FGG] Contexto da extensão inválido (recarregue a página).');
    }
  }
})();